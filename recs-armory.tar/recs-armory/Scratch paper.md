# Scratch paper

Requirements (to be installed):
helm   
gcloud CLI
az cli
kubectl 
kubelogin 
istioct


recs-armory/
├── .github/
│   └── workflows/
│       └── docker-build.yml
├── src/
│   └── app.py
├── tests/
├── Dockerfile
├── .gitignore
└── README.md